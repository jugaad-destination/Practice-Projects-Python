# Facebook Video Downloader

A GUI downloader used to download Facebook video by providing URL of the Post

## Installation

> pip3 install -r requirements.txt

## Usage
- Run command python3 script.py
- A GUI Will Appear
- Provide the URL of the Video in the field and click `Download`.

## Output

Downloaded video you desired in the same directory of the script.



