# Textfile analysis
##### Execute
`python textfile_analysis.py <textfile>`
