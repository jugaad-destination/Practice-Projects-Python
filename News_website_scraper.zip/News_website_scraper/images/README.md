home.jpg - main news page

nextpage.jpg - links to next pages

result.jpg - Snapshot of result json file
