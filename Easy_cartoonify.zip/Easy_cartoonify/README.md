# OpenCV Cartoonify

This script uses the OpenCV library to process images and outputs cartoon-like images and allows the user to process images without worrying about the directory of the image with a terminal based basic UI. 

### The Significance of This Particular Cartoon Converter Script

This script finds your image file in your pc and automatically changes its the working directory before it starts processing the image. This operation saves the time and energy of the user.  

#### Future Of This Project

Please keep in mind that this is the first version of the project and currenty only has 2 options for the cartoon styles. I will add much more depth to the cartoonify-ing process later on.
