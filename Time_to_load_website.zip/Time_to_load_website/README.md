## Time to load website 

This script takes a url from the user and returns the time taken to load that website.

## How to use this ?

1. Just type the following on the command prompt:

python time_to_load_website.py

2. It will reuest you to provide a url. Provide the url and hit enter to see the script in action.

## Sample use:

<p align = "center">
	<img src="sample.PNG" alt="sample">
</p>
