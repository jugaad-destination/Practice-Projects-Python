# Website Blocker

This script lets you block websites on your computer by editing your hosts file.


### Usage
First add your Blocked Websites to the array in both scripts.

On Linux: `sudo python website_blocker.py`
On Windows, run the script as Administrator

To unblock the websites, run the `website_unblocker.py` script.


