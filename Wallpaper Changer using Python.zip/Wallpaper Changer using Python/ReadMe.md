# Wallpaper-Changer-using-Python


## Dependencies:

Get Your API HERE :- [Unsplash](https://unsplash.com/developers)

*Wget*
```python

pip install wget
```

## Add API KEY in Wallpapers.py file:

```
access_key = '' # add your unspash api key here
```

## Run:

```
python wallpapers.py 
```


