

### Prerequisites
* beautifulsoup4
* requests
 Run `pip install -r requirements.txt` to install required external modules.

### How to run the script
Execute `python3 quote_scraper.py`

