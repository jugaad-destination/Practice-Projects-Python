# Speed Test
Speed Test using python


## Dependencies:

*youtube_dl*
```
pip3 install speedtest-cli
```
