

Solve Sudoku , or let Python solve it for you!

## Features :boom: ???

- [X] Play sudoku yourself
- [X] Let Python play and solve it for you!
- [X] Generate random sudoku puzzle



## Built with
- [Python3](https://www.python.org/)




