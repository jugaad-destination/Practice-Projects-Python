# Wikipedia infobox scraper

- The given python script uses beautifulSoup to scrape Wikipedia pages according to the given user query and obtain data from its wikipedia infobox.

## Requirements: 

```
$ pip install -r requirements.txt
```
