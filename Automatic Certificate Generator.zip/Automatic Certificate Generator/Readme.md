## Automatic-Certificate-Generator

This python script automatically generates certificate by using a certificate template and csv file which contains the list of names to be printed on certificate. It downloads the certificate in the directory i.e. in **pictures** folder where the scripts are there.

## Installation

First of all install [python]("https://www.python.org/downloads/") on your system.
```bash
pip install PI
pip install Pandas
pip install pillow
```


