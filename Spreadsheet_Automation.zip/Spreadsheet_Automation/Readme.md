

## Spreadsheet Automation Functionalities : 🚀

- First upload two datasets
- The script will we compare the two datasets
- The output will be a pie chart

## Spreadsheet Automation Instructions: 👨🏻‍💻

### Step 1:

    Open Termnial 💻

### Step 2:

    Locate to the directory where python file is located 📂

### Step 3:

    Run the command: python script.py/python3 script.py 🧐

### Step 4:

    Sit back and Relax. Let the Script do the Job. ☕

### Requirements

    - pandas
    - plotly

