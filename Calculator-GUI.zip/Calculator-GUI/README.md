<h1 align="center">Calculator (GUI)</h1>
It is GUI based calculator used to calculate any simple mathematical equation.

---------------------------------------------------------------------

## Modules Used
- tkinter
## How it works
- It takes the mathematical equation by the User.

- It returns the result of the mathematical equation.
