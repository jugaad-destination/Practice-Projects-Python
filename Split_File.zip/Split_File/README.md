# Split Files
##### About
This accepts split index and file name than spilts it according to the index provided.

### Prerequisites
To execute this script python must be installed the host system.

### How to run the script
just type this in the terminal:-
`python split_files.py <csv/text_file> <split/line_number>`


