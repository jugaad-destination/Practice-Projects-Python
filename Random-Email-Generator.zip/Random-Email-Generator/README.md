# This is a Python Script which generates random email addresses

## Requirements

## For this script to run you need to have progressbar package installed 

## Run the command in terminal to install package

```
$ pip install progressbar
```
## Run the program using command

``` 
$ python random_email_generator.py
```