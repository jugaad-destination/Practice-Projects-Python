# Script Title
<!--Remove the below lines and add yours -->
With the help of this program, you can check whether a year is leap year or not.
### Prerequisites
<!--Remove the below lines and add yours -->
No pre-requisites are required...😀😀
### How to run the script
<!--Remove the below lines and add yours -->
You can run this on any ide or online compiler.

