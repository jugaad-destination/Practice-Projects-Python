# Download GeeksForGeeks Articles as pdf
<!--Remove the below lines and add yours -->
This script take a link of GeeksForGeeks article as input and download the complete article as a pdf at default download location.

### Prerequisites
<!--Remove the below lines and add yours -->
* selenium
* requests
* webdriver-manager
* Run `pip install -r requirements.txt` to install required external modules.

### How to run the script
<!--Remove the below lines and add yours -->
- Execute `python3 downloader.py`
- Type in URL of article when prompted.



