# Instagram Unfollowers Bot

## Install Chrome Driver

- https://chromedriver.storage.googleapis.com/index.html?path=90.0.4430.24/

## Install Selenium

- pip3 install selenium
