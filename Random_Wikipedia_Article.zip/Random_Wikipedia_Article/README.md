# Random Wikipedia Article
An application to save any random article from Wikipedia to a text file.

Use:
``` pip install htmlparser``` and ``` pip install beautifulsoup4```
