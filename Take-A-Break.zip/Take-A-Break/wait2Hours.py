import time 

time.sleep(10)