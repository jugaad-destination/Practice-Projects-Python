

## Dependencies:

*github*
```
pip3 install github
```

*Add uername and password in GitHub.py file*
```
username = "" #Insert your github username here
password = "" #Insert your github password here

```


