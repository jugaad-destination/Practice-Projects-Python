# Number Guessing Game

This game allows you to check your luck and intuition :)
You should find the number computer guessed

### Usage
Just run "python main.py" in cmd command line after setting the project directory

### Here you can see sample
![Image](./image.png)

