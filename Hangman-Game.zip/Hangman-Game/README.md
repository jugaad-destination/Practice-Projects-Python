# HangMan Game

A simple Hangman game using Python

***Requirements***

first install pygame package in your system open your terminal and write `pip install pygame` this will install pygame in your system, random and time module is already installed in python by default so don't waste your time. And that is all you can now simply run main.py
