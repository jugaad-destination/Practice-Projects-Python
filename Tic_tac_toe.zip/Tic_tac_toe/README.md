# Tic Tac Toe

## Description

A python based 2-player Tic Tac Toe game.
It takes input for the respective x and y coordinates of the two players.
The two players are named as X and O
and will enter their desired coordinates alternatively to win the game.


## Prerequisites

Use any Python online compiler of download python IDE from https://www.python.org/

## How to run

Just run

```sh
python tic_tac_toe.py
```

<!-- ## Screenshots/Demo -->

