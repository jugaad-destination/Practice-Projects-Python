## A Simple Rock Paper Scissors Game:
##### To be Played with a Computer.
* You can enter the number of games you want to play.
* There is also a score window which is displayed after every turn.


