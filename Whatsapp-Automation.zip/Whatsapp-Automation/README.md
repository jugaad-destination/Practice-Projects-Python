## How to run this Python Script?

1. Install  [chromedriver](https://chromedriver.storage.googleapis.com/index.html?path=2.25/)  ( choose your specific version )
2. `pip install selenium`
3. Make sure you have added the **correct path** to your chrome driver
4. Enter the name of the person you want to send the message to **exactly the way it is saved.**
5. Type in the message you want to send.
6. You will have **15s** to scan for whatsapp web.
7. Message has been sent.


