
# Dependencies:

*pyinstaller*
```
pip install pyinstaller
```

# ADD PATH FOR TEXT EDITOR OR IDE HERE:

```
codePath = "C:\\Program Files\\Sublime Text 3\\sublime_text.exe"#ADD THE PATH OF TXET EDITOR OR IDE HERE
```

# Run:
Convert  the python file into .exe 
```
pyinstaller -F workstation.py
```

# Start-Up Setup

1.PRESS WINDOWS + R to open RUN

2.Type 
```
shell:startup
```

3.Copy the exe file to start-up folder 

4.Restart the system it should run the exe as soon as system starts
